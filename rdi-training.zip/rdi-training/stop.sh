docker-compose down -v --remove-orphans
rm -rf rdi-installation-1.10.0.tar.gz
rm -rf rdi_install
